Maintainers List
================

For notes on how to read this information, please refer to `MAINTAINERS.md` in
the main Unikraft repository.

	LIBNGINX-UNIKRAFT
	M:	Mihai Pogonaru <pogonarumihai@gmail.com>
	M:	Costin Lupu <costin.lupu@cs.pub.ro>
	L:	minios-devel@lists.xen.org
	F: *
