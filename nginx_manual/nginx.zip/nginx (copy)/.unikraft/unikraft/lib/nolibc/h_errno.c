/* SPDX-License-Identifier: BSD-3-Clause */
/*
 * Authors: Razvan Deaconescu <razvand@unikraft.io>
 *
 * Copyright (c) 2022, Unikraft GmbH. All rights reserved.
 */

#include <netdb.h>

int h_errno;
